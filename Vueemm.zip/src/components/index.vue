<template>
	<div>
		<div id="box">
			<div class="content">
				<p class="title">这里是标题</p>
				<p class="nr">这里是内容</p>
			</div>
			<button @click="falses()">取消</button>
			<button @click="trues()">确认</button>
		</div>
		
		
		<true :name="childName"></true>
		<false :name="childName2"></false>
	</div>
</template>

<script>
import True from "./trues"
import False from "./false"

	export default{
		components:{
		  	True,
		  	False
		},
		data() {
		    return {
		      childName: 'child name is what?',
		      childName2: '点击取消改变'
		    };
		  },
		methods:{
			trues(){
				this.childName = 'no name';
			},
			falses(){
				this.childName2 = '我是取消';				
			}
		}
	}
</script>

<style>
	html,body{
		background: pink;
	}
	#box{
		position: absolute;
		left: 40%;
		top: 25%;
		border-radius: 50px;
		font-size: 0;
		background: white;
	}
	.content{
		width: 300px;
		height: 130px;
		background: white;
		font-size: 16px;
		border-top-right-radius: 10px;
		border-top-left-radius: 10px;
		border-bottom: 1px solid lightgray;
		padding-top: 10px;
	}
	.nr{
		margin-left: 20px;
		margin-top: 10px;
		color: lightblue;
	}
	.title{
		text-align: center;
	}
	button{
		width: 150px;
		height: 40px;
		background: white;
		border: 0;
		cursor: pointer;
	}
	button:nth-of-type(1){
		border-right: 1px solid lightgray;
		border-bottom-left-radius: 10px;
	}
	button:nth-of-type(2){
		border-bottom-right-radius: 10px;
	}
	
</style>