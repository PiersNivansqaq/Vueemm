<template>
	<div>
		{{name}}
	</div>
</template>

<script>
	export default{
		props: ['name']
	}
</script>

<style>
</style>