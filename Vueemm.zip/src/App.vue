<template>
  <div id="app">	
    <router-view></router-view/>
  </div>
</template>

<script>

export default {
  name: 'App',
  components:{
			
  }
}
</script>

<style lang="scss">
*{
	margin: 0;
	padding: 0;
	list-style: none;
}
a{
	color: white;
	text-decoration: none;
}
</style>
